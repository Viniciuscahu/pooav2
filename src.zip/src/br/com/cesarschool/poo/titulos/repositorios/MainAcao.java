package br.com.cesarschool.poo.titulos.repositorios;

public class MainAcao {
    public static void main(String[] args) {
    }
}
